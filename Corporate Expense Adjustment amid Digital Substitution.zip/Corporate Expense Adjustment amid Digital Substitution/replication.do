/*
Corporate Expense Adjustment amid Digital Substitution
Data: 29,419 firm-years, 4,570 firms, 2016-2024; 133 variables.
All financial/governance data and 2019 supplementary inputs are in data.dta.
Original source-year coverage is 2015-2024; saved panel contains annual changes.

Run in Stata 18:
  cd "directory containing these three files"
  do "replication.do"
or: do "full/path/replication.do" "full/path/package-directory"

This script uses built-in Stata commands only and writes results into results/.
Regressions use ten lagged controls, except the explicitly uncontrolled baseline.
Firm characteristics retain their original 2019 standardization/missingness.
Some manuscript values were manually revised by the author. This program
estimates the available data; it does not insert manually revised coefficients.
Clustered and conventional Wald inference are explicitly labelled separately.
*/
version 18.0
clear all
set more off
set linesize 160
args package_dir
if `"`package_dir'"' != "" cd `"`package_dir'"'
confirm file "data.dta"
capture mkdir "results"
capture log close _all
log using "results/replication.log", text replace
use "data.dta", clear
isid firmid year
xtset firmid year
local controls roa_lag lev_lag size_lag assetint_lag employeeint_lag soe_lag growth_lag cashratio_lag top1_lag duality_lag
egen byte nmissing = rowmiss(d_lt d_lr post_dlr `controls')
gen byte sample10 = nmissing == 0
drop nmissing

tempname coefs tests
tempfile coefdata testdata
postfile `coefs' str48 model str64 term double b se t p long N double df_r r2 using `coefdata', replace
postfile `tests' str48 model str72 hypothesis str24 covariance double estimate se t p F long N using `testdata', replace
capture program drop record_model
program define record_model
    args handle model
    local terms : colnames e(b)
    foreach term of local terms {
        local b = _b[`term']
        local se = _se[`term']
        local t = cond(`se'>0, `b'/`se', .)
        local p = cond(`se'>0, 2*ttail(e(df_r),abs(`t')), .)
        post `handle' ("`model'") ("`term'") (`b') (`se') (`t') (`p') (e(N)) (e(df_r)) (e(r2))
    }
end
capture program drop record_test
program define record_test
    args handle model covariance expression
    quietly lincom `expression'
    local b = r(estimate)
    local se = r(se)
    local t = `b'/`se'
    local p = r(p)
    quietly test `expression' = 0
    post `handle' ("`model'") ("`expression'") ("`covariance'") (`b') (`se') (`t') (`p') (r(F)) (e(N))
end

* 1. Descriptive statistics and annual expense profiles.
gen double travel_10k = travel_w / 10000
gen double travel_revenue_pct = 100 * travel_w / revenue_w
gen double travel_sga_pct = 100 * travel_w / (selling_expense_w + admin_expense_w)
tempname desc
tempfile descdata
postfile `desc' str32 variable long N double mean sd median min max using `descdata', replace
foreach v in travel_10k travel_revenue_pct travel_sga_pct d_lt d_lr `controls' {
    quietly summarize `v', detail
    post `desc' ("`v'") (r(N)) (r(mean)) (r(sd)) (r(p50)) (r(min)) (r(max))
}
postclose `desc'
preserve
use `descdata', clear
export excel using "results/results.xlsx", sheet("Descriptive") firstrow(variables) replace
restore
preserve
collapse (mean) travel_w entertain_w (count) N_travel=travel_w N_entertain=entertain_w, by(year)
quietly summarize travel_w if year == 2019, meanonly
gen double travel_index = 100*travel_w/r(mean)
quietly summarize entertain_w if year == 2019, meanonly
gen double entertain_index = 100*entertain_w/r(mean)
export excel using "results/results.xlsx", sheet("Annual", replace) firstrow(variables)
twoway (connected travel_index year) (connected entertain_index year), yline(100, lpattern(dash)) legend(order(1 "Travel" 2 "Business entertainment")) ytitle("2019 = 100") xtitle("Year")
graph export "results/annual_expense_indices.png", replace width(2400)
restore

* 2. Revenue elasticity: uncontrolled and ten-control models, same sample.
areg d_lt d_lr post_dlr i.year if sample10, absorb(firmid) vce(cluster firmid)
record_model `coefs' H1_no_controls_same_sample
record_test `tests' H1_no_controls_same_sample cluster_firm "d_lr + post_dlr"
areg d_lt d_lr post_dlr `controls' i.year if sample10, absorb(firmid) vce(cluster firmid)
record_model `coefs' H1_ten_controls
record_test `tests' H1_ten_controls cluster_firm "post_dlr"
record_test `tests' H1_ten_controls cluster_firm "d_lr + post_dlr"

* 3. Cost stickiness: 2016-2019 versus 2023-2024.
areg d_lt d_lr d_lr_dec `controls' i.year if sample10 & inrange(year,2016,2019), absorb(firmid) vce(cluster firmid)
record_model `coefs' H2_pre
areg d_lt d_lr d_lr_dec `controls' i.year if sample10 & inrange(year,2023,2024), absorb(firmid) vce(cluster firmid)
record_model `coefs' H2_post
areg d_lt d_lr post_dlr d_lr_dec post_dlr_dec `controls' i.year if sample10 & (year<=2019 | year>=2023), absorb(firmid) vce(cluster firmid)
record_model `coefs' H2_difference_clustered
record_test `tests' H2_difference_clustered cluster_firm "post_dlr_dec"
record_test `tests' H2_post_combined cluster_firm "d_lr_dec + post_dlr_dec"
areg d_lt d_lr post_dlr d_lr_dec post_dlr_dec `controls' i.year if sample10 & (year<=2019 | year>=2023), absorb(firmid)
record_model `coefs' H2_difference_conventional
record_test `tests' H2_difference_conventional conventional "post_dlr_dec"

* 4. Robustness: transition exclusion and 2018/2019 placebos.
areg d_lt d_lr post_dlr `controls' i.year if sample10 & (year<=2019 | year>=2023), absorb(firmid) vce(cluster firmid)
record_model `coefs' H1_no_transition
foreach yr in 2018 2019 {
    gen double fake_dlr = (year>=`yr')*d_lr if year<=2019
    areg d_lt d_lr fake_dlr `controls' i.year if sample10 & year<=2019, absorb(firmid) vce(cluster firmid)
    record_model `coefs' Placebo_`yr'
    drop fake_dlr
}

* 5. Heterogeneity: organizational flexibility and offline dependence.
foreach z in ana_attention_2019_z opc_2019_z physical_z rdint_z {
    gen double z_lr = `z'*d_lr
    gen double z_post = `z'*post
    gen double z_post_lr = `z'*post*d_lr
    areg d_lt d_lr post_dlr z_lr z_post z_post_lr `controls' i.year if sample10, absorb(firmid) vce(cluster firmid)
    record_model `coefs' H4_`z'
    record_test `tests' H4_`z' cluster_firm "z_post_lr"
    drop z_lr z_post z_post_lr
}

* 6. Six expense categories: original within-category samples and common sample.
foreach v in meeting comm travel office entertain car {
    gen double category_log = ln(`v'_w) if `v'_w>0
    gen double dy_`v' = D.category_log
    drop category_log
    areg dy_`v' d_lr post_dlr `controls' i.year if sample10, absorb(firmid) vce(cluster firmid)
    record_model `coefs' H3_`v'_available
}
egen byte h3_missing = rowmiss(dy_meeting dy_comm dy_travel dy_office dy_entertain dy_car d_lr post_dlr `controls')
foreach v in meeting comm travel office entertain car {
    areg dy_`v' d_lr post_dlr `controls' i.year if h3_missing==0, absorb(firmid) vce(cluster firmid)
    record_model `coefs' H3_`v'_common
}
preserve
keep if h3_missing==0
keep firmid year d_lr post_dlr dy_* `controls'
reshape long dy_, i(firmid year) j(category_name) string
encode category_name, gen(category)
egen long firm_category = group(firmid category)
local xvars
foreach v in meeting comm travel office entertain car {
    gen double slope_`v' = d_lr*(category_name=="`v'")
    gen double break_`v' = post_dlr*(category_name=="`v'")
    local xvars `xvars' slope_`v' break_`v'
}
local category_controls
foreach v of local controls {
    local category_controls `category_controls' c.`v'##i.category
}
areg dy_ `xvars' i.year#i.category `category_controls', absorb(firm_category) vce(cluster firmid)
record_model `coefs' H3_common_stacked
record_test `tests' H3_group_mean_difference cluster_firm "(break_meeting+break_comm+break_travel)/3-(break_office+break_entertain+break_car)/3"
test break_meeting=break_comm=break_travel=break_office=break_entertain=break_car
post `tests' ("H3_joint_equality") ("All six breaks equal") ("cluster_firm") (.) (.) (.) (r(p)) (r(F)) (e(N))
local cats meeting comm travel office entertain car
forvalues a=1/5 {
    local va : word `a' of `cats'
    local next=`a'+1
    forvalues b=`next'/6 {
        local vb : word `b' of `cats'
        record_test `tests' H3_pair_`va'_`vb' cluster_firm "break_`va'-break_`vb'"
    }
}
restore

* 7. On-site audit comparison: paired firm-years, fully interacted model.
gen byte audit_pair = sample10 & !missing(d_lt,d_lo)
areg d_lo d_lr post_dlr `controls' i.year if audit_pair, absorb(firmid) vce(cluster firmid)
record_model `coefs' Audit_other_fee_paired
areg d_lt d_lr post_dlr `controls' i.year if audit_pair, absorb(firmid) vce(cluster firmid)
record_model `coefs' Audit_travel_paired
preserve
keep if audit_pair
keep firmid year d_lt d_lo d_lr post_dlr `controls'
rename d_lt audit_ytravel
rename d_lo audit_yother
reshape long audit_y, i(firmid year) j(expense_name) string
gen byte travel_type = expense_name=="travel"
egen long firm_expense = group(firmid travel_type)
local audit_controls
foreach v of local controls {
    local audit_controls `audit_controls' c.`v'##i.travel_type
}
areg audit_y c.d_lr##i.travel_type c.post_dlr##i.travel_type `audit_controls' i.year#i.travel_type, absorb(firm_expense) vce(cluster firmid)
record_model `coefs' Audit_stacked_difference
record_test `tests' Audit_stacked_difference cluster_firm "1.travel_type#c.post_dlr"
restore

* 8. Dynamic paths, 2019 reference year, with/without 2020-2022.
tempname dynamic
tempfile dynamicdata
postfile `dynamic' str20 sample str8 outcome int year double b se t p df_r long N using `dynamicdata', replace
foreach sample in all no_transition {
    local restriction "sample10"
    local years 2016 2017 2018 2020 2021 2022 2023 2024
    if "`sample'"=="no_transition" {
        local restriction "sample10 & (year<=2019 | year>=2023)"
        local years 2016 2017 2018 2023 2024
    }
    local slopes
    local stickies
    foreach yr of local years {
        gen double dynamic_slope`yr' = d_lr*(year==`yr')
        gen double dynamic_sticky`yr' = d_lr_dec*(year==`yr')
        local slopes `slopes' dynamic_slope`yr'
        local stickies `stickies' dynamic_sticky`yr'
    }
    foreach outcome in H1 H2 {
        if "`outcome'"=="H1" {
            areg d_lt d_lr `slopes' `controls' i.year if `restriction', absorb(firmid) vce(cluster firmid)
            local prefix dynamic_slope
        }
        else {
            areg d_lt d_lr d_lr_dec `slopes' `stickies' `controls' i.year if `restriction', absorb(firmid) vce(cluster firmid)
            local prefix dynamic_sticky
        }
        record_model `coefs' Dynamic_`outcome'_`sample'
        foreach yr of local years {
            local b=_b[`prefix'`yr']
            local se=_se[`prefix'`yr']
            if `se'>0 {
                local t=`b'/`se'
                local p=2*ttail(e(df_r),abs(`t'))
                post `dynamic' ("`sample'") ("`outcome'") (`yr') (`b') (`se') (`t') (`p') (e(df_r)) (e(N))
            }
        }
        post `dynamic' ("`sample'") ("`outcome'") (2019) (0) (0) (.) (.) (e(df_r)) (e(N))
        test `prefix'2017 `prefix'2018
        post `tests' ("Pretrend_`outcome'_`sample'") ("2017 and 2018 jointly zero") ("cluster_firm") (.) (.) (.) (r(p)) (r(F)) (e(N))
    }
    foreach yr of local years {
        drop dynamic_slope`yr' dynamic_sticky`yr'
    }
}
postclose `dynamic'
postclose `coefs'
postclose `tests'
use `coefdata', clear
sort model term
export excel using "results/results.xlsx", sheet("Regressions", replace) firstrow(variables)
export delimited using "results/regressions.csv", replace
use `testdata', clear
sort model
export excel using "results/results.xlsx", sheet("Wald_tests", replace) firstrow(variables)
export delimited using "results/wald_tests.csv", replace
use `dynamicdata', clear
sort sample outcome year
gen double ci_low = b-invttail(df_r,0.025)*se
gen double ci_high = b+invttail(df_r,0.025)*se
export excel using "results/results.xlsx", sheet("Dynamic", replace) firstrow(variables)
export delimited using "results/dynamic.csv", replace
foreach sample in all no_transition {
    foreach outcome in H1 H2 {
        twoway (rcap ci_low ci_high year if sample=="`sample'" & outcome=="`outcome'") (connected b year if sample=="`sample'" & outcome=="`outcome'"), yline(0, lpattern(dash)) xline(2019.5, lpattern(dash)) xtitle("Year") ytitle("Difference relative to 2019") title("`outcome': `sample'") legend(off)
        graph export "results/dynamic_`outcome'_`sample'.png", replace width(2400)
    }
}
display "REPLICATION_COMPLETED"
log close
